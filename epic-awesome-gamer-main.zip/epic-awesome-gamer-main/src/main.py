# -*- coding: utf-8 -*-
# Time       : 2022/1/16 0:24
# Author     : QIN2DIM
# Github     : https://github.com/QIN2DIM
# Description: 🚀 哟！Epic免费人！
from fire import Fire

from services.scaffold import Scaffold

if __name__ == "__main__":
    Fire(Scaffold)
